import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  testimonials: defineTable({
    name: v.string(),
    content: v.string(),
    rating: v.number(),
    location: v.string(),
    imageUrl: v.optional(v.string()),
  }),
  contactSubmissions: defineTable({
    name: v.string(),
    email: v.string(),
    phone: v.optional(v.string()),
    service: v.string(),
    message: v.string(),
    status: v.string(), // "new", "contacted", "completed"
  }).index("by_status", ["status"]),
  services: defineTable({
    title: v.string(),
    description: v.string(),
    icon: v.string(),
    features: v.array(v.string()),
    price: v.optional(v.string()),
  }),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
