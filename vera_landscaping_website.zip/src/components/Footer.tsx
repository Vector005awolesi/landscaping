import { Link } from "react-router-dom";
import { Leaf, Phone, Mail, MapPin, Facebook, Instagram, Twitter } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-green-800 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center space-x-2 mb-4">
              <Leaf className="h-8 w-8 text-green-400" />
              <span className="text-2xl font-bold">Vera Landscaping</span>
            </div>
            <p className="text-green-100 mb-4 max-w-md">
              Transform your outdoor space with our professional landscaping services. 
              We bring nature's beauty to your doorstep with expert design and maintenance.
            </p>
            <div className="flex space-x-4">
              <Facebook className="h-6 w-6 text-green-400 hover:text-white cursor-pointer transition-colors" />
              <Instagram className="h-6 w-6 text-green-400 hover:text-white cursor-pointer transition-colors" />
              <Twitter className="h-6 w-6 text-green-400 hover:text-white cursor-pointer transition-colors" />
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><Link to="/" className="text-green-100 hover:text-white transition-colors">Home</Link></li>
              <li><Link to="/about" className="text-green-100 hover:text-white transition-colors">About</Link></li>
              <li><Link to="/services" className="text-green-100 hover:text-white transition-colors">Services</Link></li>
              <li><Link to="/contact" className="text-green-100 hover:text-white transition-colors">Contact</Link></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Contact Info</h3>
            <div className="space-y-3">
              <div className="flex items-center space-x-2">
                <Phone className="h-5 w-5 text-green-400" />
                <span className="text-green-100">(555) 123-4567</span>
              </div>
              <div className="flex items-center space-x-2">
                <Mail className="h-5 w-5 text-green-400" />
                <span className="text-green-100">info@veralandscaping.com</span>
              </div>
              <div className="flex items-center space-x-2">
                <MapPin className="h-5 w-5 text-green-400" />
                <span className="text-green-100">123 Garden St, Green Valley, CA</span>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-green-700 mt-8 pt-8 text-center">
          <p className="text-green-100">
            © 2024 Vera Landscaping. All rights reserved. | Designed with nature in mind.
          </p>
        </div>
      </div>
    </footer>
  );
}
