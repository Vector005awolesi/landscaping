import { Users, Award, Leaf, Heart } from "lucide-react";

const stats = [
  { number: "500+", label: "Projects Completed" },
  { number: "14", label: "Years Experience" },
  { number: "50+", label: "Happy Clients" },
  { number: "100%", label: "Satisfaction Rate" }
];

const values = [
  {
    icon: Leaf,
    title: "Sustainability",
    description: "We prioritize eco-friendly practices and native plant selections to create sustainable landscapes."
  },
  {
    icon: Heart,
    title: "Passion",
    description: "Our love for nature and design drives us to create outdoor spaces that inspire and delight."
  },
  {
    icon: Award,
    title: "Quality",
    description: "We maintain the highest standards in every project, ensuring lasting beauty and functionality."
  },
  {
    icon: Users,
    title: "Community",
    description: "We're committed to serving our local community and building lasting relationships with our clients."
  }
];

export default function About() {
  return (
    <div className="pt-16">
      {/* Hero Section */}
      <section className="py-20 bg-green-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-5xl font-bold text-gray-800 mb-6">About Vera Landscaping</h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Transforming outdoor spaces with passion, expertise, and a deep respect for nature
            </p>
          </div>
        </div>
      </section>

      {/* Story Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-bold text-gray-800 mb-6">Our Story</h2>
              <p className="text-lg text-gray-600 mb-6">
                Founded in 2010 by Maria Vera, our company began with a simple vision: to create 
                beautiful, sustainable outdoor spaces that bring people closer to nature. What started 
                as a small family business has grown into one of the region's most trusted landscaping companies.
              </p>
              <p className="text-lg text-gray-600 mb-6">
                Maria's background in environmental science and her passion for horticulture laid the 
                foundation for our commitment to sustainable practices. Today, our team of certified 
                landscapers, designers, and arborists continues to uphold these values while delivering 
                exceptional results for our clients.
              </p>
              <p className="text-lg text-gray-600">
                Every project we undertake is an opportunity to create something beautiful, functional, 
                and environmentally responsible. We believe that great landscaping should enhance both 
                the property and the surrounding ecosystem.
              </p>
            </div>
            <div>
              <img
                src="https://images.unsplash.com/photo-1560472354-b33ff0c44a43?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
                alt="Our team at work"
                className="rounded-lg shadow-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 bg-green-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-4xl md:text-5xl font-bold text-white mb-2">
                  {stat.number}
                </div>
                <div className="text-green-100 text-lg">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-800 mb-4">Our Values</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              These core principles guide everything we do and shape our approach to every project
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <div key={index} className="text-center">
                <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <value.icon className="h-8 w-8 text-green-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-800 mb-3">{value.title}</h3>
                <p className="text-gray-600">{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-800 mb-4">Meet Our Team</h2>
            <p className="text-xl text-gray-600">
              Experienced professionals dedicated to bringing your vision to life
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <img
                src="https://images.unsplash.com/photo-1494790108755-2616b612b786?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80"
                alt="Maria Vera"
                className="w-48 h-48 rounded-full object-cover mx-auto mb-4"
              />
              <h3 className="text-xl font-semibold text-gray-800 mb-2">Maria Vera</h3>
              <p className="text-green-600 font-medium mb-3">Founder & Lead Designer</p>
              <p className="text-gray-600">
                Environmental scientist turned landscape designer with 15+ years of experience 
                creating sustainable outdoor spaces.
              </p>
            </div>
            <div className="text-center">
              <img
                src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80"
                alt="James Rodriguez"
                className="w-48 h-48 rounded-full object-cover mx-auto mb-4"
              />
              <h3 className="text-xl font-semibold text-gray-800 mb-2">James Rodriguez</h3>
              <p className="text-green-600 font-medium mb-3">Master Arborist</p>
              <p className="text-gray-600">
                Certified arborist specializing in tree care, pruning, and disease management 
                with over 12 years of experience.
              </p>
            </div>
            <div className="text-center">
              <img
                src="https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80"
                alt="Sarah Chen"
                className="w-48 h-48 rounded-full object-cover mx-auto mb-4"
              />
              <h3 className="text-xl font-semibold text-gray-800 mb-2">Sarah Chen</h3>
              <p className="text-green-600 font-medium mb-3">Irrigation Specialist</p>
              <p className="text-gray-600">
                Expert in water-efficient irrigation systems and sustainable water management 
                for residential and commercial properties.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
