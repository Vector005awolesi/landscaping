import ServiceCard from "../components/ServiceCard";
import { 
  Scissors, 
  TreePine, 
  Sprout, 
  Droplets, 
  Hammer, 
  Flower,
  Truck,
  Shield
} from "lucide-react";

const services = [
  {
    icon: Scissors,
    title: "Lawn Care & Maintenance",
    description: "Complete lawn care services to keep your grass healthy and beautiful year-round",
    features: [
      "Weekly/bi-weekly mowing",
      "Fertilization programs",
      "Weed and pest control",
      "Aeration and overseeding",
      "Seasonal cleanup"
    ]
  },
  {
    icon: TreePine,
    title: "Tree & Shrub Services",
    description: "Professional tree care from certified arborists to maintain healthy, beautiful trees",
    features: [
      "Tree pruning and trimming",
      "Tree removal and stump grinding",
      "Disease diagnosis and treatment",
      "Emergency storm damage cleanup",
      "Shrub maintenance and shaping"
    ]
  },
  {
    icon: Sprout,
    title: "Garden Design & Installation",
    description: "Custom garden design and installation services tailored to your space and preferences",
    features: [
      "Landscape design consultation",
      "Plant selection and sourcing",
      "Garden bed preparation",
      "Seasonal flower installation",
      "Vegetable garden setup"
    ]
  },
  {
    icon: Droplets,
    title: "Irrigation Systems",
    description: "Efficient watering solutions to keep your landscape healthy while conserving water",
    features: [
      "Sprinkler system installation",
      "Drip irrigation setup",
      "Smart controller installation",
      "System maintenance and repairs",
      "Water efficiency audits"
    ]
  },
  {
    icon: Hammer,
    title: "Hardscaping",
    description: "Beautiful stone and concrete features that add structure and elegance to your landscape",
    features: [
      "Patio and walkway installation",
      "Retaining wall construction",
      "Fire pit and outdoor kitchen setup",
      "Decorative stone work",
      "Drainage solutions"
    ]
  },
  {
    icon: Flower,
    title: "Seasonal Services",
    description: "Year-round maintenance to keep your landscape looking its best in every season",
    features: [
      "Spring cleanup and preparation",
      "Summer maintenance programs",
      "Fall leaf removal",
      "Winter protection services",
      "Holiday decoration installation"
    ]
  },
  {
    icon: Truck,
    title: "Commercial Landscaping",
    description: "Professional landscaping services for businesses, HOAs, and commercial properties",
    features: [
      "Property maintenance contracts",
      "Commercial design services",
      "Large-scale installations",
      "Snow removal services",
      "Parking lot landscaping"
    ]
  },
  {
    icon: Shield,
    title: "Landscape Restoration",
    description: "Restore damaged or neglected landscapes to their full potential",
    features: [
      "Soil rehabilitation",
      "Erosion control",
      "Native plant restoration",
      "Damaged area repair",
      "Sustainable redesign"
    ]
  }
];

export default function Services() {
  return (
    <div className="pt-16">
      {/* Hero Section */}
      <section className="py-20 bg-green-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl font-bold text-gray-800 mb-6">Our Services</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Comprehensive landscaping solutions for residential and commercial properties. 
            From design to maintenance, we've got your outdoor space covered.
          </p>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <ServiceCard key={index} {...service} />
            ))}
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-800 mb-4">Our Process</h2>
            <p className="text-xl text-gray-600">
              From initial consultation to project completion, we ensure a smooth and professional experience
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="bg-green-600 text-white w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                1
              </div>
              <h3 className="text-xl font-semibold text-gray-800 mb-3">Consultation</h3>
              <p className="text-gray-600">
                We meet with you to discuss your vision, assess your space, and understand your needs and budget.
              </p>
            </div>
            <div className="text-center">
              <div className="bg-green-600 text-white w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                2
              </div>
              <h3 className="text-xl font-semibold text-gray-800 mb-3">Design</h3>
              <p className="text-gray-600">
                Our team creates a detailed design plan that brings your vision to life while considering your site's unique characteristics.
              </p>
            </div>
            <div className="text-center">
              <div className="bg-green-600 text-white w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                3
              </div>
              <h3 className="text-xl font-semibold text-gray-800 mb-3">Installation</h3>
              <p className="text-gray-600">
                Our skilled team implements the design with attention to detail, quality materials, and professional craftsmanship.
              </p>
            </div>
            <div className="text-center">
              <div className="bg-green-600 text-white w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                4
              </div>
              <h3 className="text-xl font-semibold text-gray-800 mb-3">Maintenance</h3>
              <p className="text-gray-600">
                We provide ongoing maintenance services to ensure your landscape continues to thrive and look its best.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-green-600">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl font-bold text-white mb-6">
            Ready to Get Started?
          </h2>
          <p className="text-xl text-green-100 mb-8">
            Contact us today for a free consultation and let's discuss how we can transform your outdoor space
          </p>
          <a
            href="/contact"
            className="bg-white text-green-600 px-8 py-3 rounded-lg text-lg font-semibold hover:bg-gray-100 transition-colors inline-block"
          >
            Get Your Free Estimate
          </a>
        </div>
      </section>
    </div>
  );
}
