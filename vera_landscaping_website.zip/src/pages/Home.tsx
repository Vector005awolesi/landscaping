import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import Hero from "../components/Hero";
import ServiceCard from "../components/ServiceCard";
import TestimonialCard from "../components/TestimonialCard";
import { Link } from "react-router-dom";
import { Scissors, TreePine, Sprout, Droplets, ArrowRight } from "lucide-react";

const services = [
  {
    icon: Scissors,
    title: "Lawn Care",
    description: "Professional lawn maintenance and care services",
    features: ["Regular mowing", "Fertilization", "Weed control", "Seasonal cleanup"]
  },
  {
    icon: TreePine,
    title: "Tree Services",
    description: "Expert tree care and maintenance",
    features: ["Tree trimming", "Tree removal", "Stump grinding", "Disease treatment"]
  },
  {
    icon: Sprout,
    title: "Garden Design",
    description: "Custom garden design and installation",
    features: ["Plant selection", "Garden planning", "Soil preparation", "Seasonal planting"]
  },
  {
    icon: Droplets,
    title: "Irrigation",
    description: "Efficient watering systems for your landscape",
    features: ["Sprinkler installation", "Drip irrigation", "System maintenance", "Water conservation"]
  }
];

export default function Home() {
  const testimonials = useQuery(api.testimonials.list) || [];

  return (
    <div>
      {/* Hero Section */}
      <Hero />

      {/* About Preview Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-bold text-gray-800 mb-6">
                Creating Beautiful Landscapes Since 2010
              </h2>
              <p className="text-lg text-gray-600 mb-6">
                At Vera Landscaping, we believe that every outdoor space has the potential 
                to become a natural masterpiece. Our team of experienced professionals 
                combines creativity with expertise to transform your vision into reality.
              </p>
              <p className="text-lg text-gray-600 mb-8">
                From residential gardens to commercial properties, we provide comprehensive 
                landscaping services that enhance the beauty and value of your property 
                while respecting the environment.
              </p>
              <Link
                to="/about"
                className="inline-flex items-center bg-green-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-green-700 transition-colors"
              >
                Learn More About Us
                <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </div>
            <div>
              <img
                src="https://images.unsplash.com/photo-1416879595882-3373a0480b5b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
                alt="Beautiful landscape design"
                className="rounded-lg shadow-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-800 mb-4">Our Services</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              We offer a comprehensive range of landscaping services to meet all your outdoor needs
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {services.map((service, index) => (
              <ServiceCard key={index} {...service} />
            ))}
          </div>
          <div className="text-center mt-12">
            <Link
              to="/services"
              className="inline-flex items-center bg-green-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-green-700 transition-colors"
            >
              View All Services
              <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      {testimonials.length > 0 && (
        <section className="py-20 bg-green-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-4xl font-bold text-gray-800 mb-4">What Our Clients Say</h2>
              <p className="text-xl text-gray-600">
                Don't just take our word for it - hear from our satisfied customers
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {testimonials.slice(0, 3).map((testimonial) => (
                <TestimonialCard key={testimonial._id} {...testimonial} />
              ))}
            </div>
          </div>
        </section>
      )}

      {/* CTA Section */}
      <section className="py-20 bg-green-600">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl font-bold text-white mb-6">
            Ready to Transform Your Outdoor Space?
          </h2>
          <p className="text-xl text-green-100 mb-8">
            Contact us today for a free consultation and let's bring your landscaping vision to life
          </p>
          <Link
            to="/contact"
            className="bg-white text-green-600 px-8 py-3 rounded-lg text-lg font-semibold hover:bg-gray-100 transition-colors inline-block"
          >
            Get Your Free Quote
          </Link>
        </div>
      </section>
    </div>
  );
}
